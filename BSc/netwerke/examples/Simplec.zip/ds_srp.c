#include <sys/types.h>		/* these includes used by the socket() call */
#include <sys/socket.h>		/* this include used by the socket() call */
#include <netdb.h>		/* used to access common network structs and constants */
#include <stdio.h>		/* standard io - e.g. stderr */
#include <stdlib.h>

#define DATA "Whoop, whoop, whoop..."	/* Temporary data until interactive data is ready */
#define SERVER_PORT 5001
#define BUFFER_SIZE 1024

/* prototypes for later function implementations */
void pdie(const char*);
void die(const char*);

int main(int argc, char* argv[]) {
  int sock;			/* fd for the socket connection */
  struct sockaddr_in server;	/* Socket struct for server connection */
  struct sockaddr_in client;	/* Socket struct for client connection */
  int clientLen;		/* Length of the client socket struct */
  struct hostent *hp;		/* return values obtained through gethostbyname() call */
  char buf[BUFFER_SIZE];	/* received data buffer */
  int i;			/* loop counter */

  if (argc != 2)
    die("Usage: ds_srp hostname");

  /* Open 5 sockets and send the same message every time */
  for (i = 0; i < 5; ++i) {
    /* Open a socket - don't bind it yet. See the appendix in ds_srpd.c for api descriptions */
    /* The type is an internet TCP type */
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
      pdie("Client opening stream socket");

    /* Get ready to connect to the server */
    bzero((char*)&server, sizeof(server));
    server.sin_family = AF_INET;
    if ((hp = gethostbyname(argv[1])) == NULL) {
      sprintf(buf, "Client %s: unknown host\n", argv[1]);
      die(buf);
    }
    bcopy(hp->h_addr, &server.sin_addr, hp->h_length);
    server.sin_port = htons((u_short) SERVER_PORT);

    /* Try to connect to server */
    /* For explanation of connect() see ds_srpd.c for api descriptions */
    if (connect(sock, (struct sockaddr*) &server, sizeof(server)) < 0)
      pdie("Client connecting stream socket");
    
    /* Determine the port that the client is using */
    clientLen = sizeof(client);
    if (getsockname(sock, (struct sockaddr *) &client, &clientLen))
      pdie("Client getting socket name");
      
    if (clientLen != sizeof(client))
      die("Client getsockname() overwrote the name structure");
      
    printf("Client socket has port %hu\n", ntohs(client.sin_port));
    
    /* Write out message */
    if (write(sock, DATA, sizeof(DATA)) < 0)
      pdie("Client writing on stream socket");
      
    /* Prepare our client buffer to read and then do so */
    bzero(buf, sizeof(buf));
    if (read(sock, buf, BUFFER_SIZE) < 0)
      pdie("Client reading stream message");
      
    printf("C: %s\n", buf);
    
    /* Close the connection */
    close(sock);
  }
  
  exit(0);
}

/**************************************************************************************
 * pdie --- Call perror() to figure out what went wrong and then die
 *************************************************************************************/
void pdie(const char* msg) {
  perror(msg);
  exit(1);
}

/**************************************************************************************
 * die --- print a error message and die
 *************************************************************************************/
void die(const char* msg) {
  fputs(msg, stderr);
  fputc('\n', stderr);
  exit(1);
}
