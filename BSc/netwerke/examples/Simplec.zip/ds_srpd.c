#include <sys/types.h>		/* these includes used by the socket() call */
#include <sys/socket.h>		/* this include used by the socket() call */
ds_inc.h#include <netdb.h>		/* used to access common network structs and constants */
#include <stdio.h>		/* standard io - e.g. stderr */
#include ds_inc.hds_inc.h<stdlib.h>

#define TRUE 1			/* use in the control structures to show friendlier logic */
#define SERVER_PORT 5001	/* allow connections to server only on this port no */
#define BUFFER_SIZE 1024	/* define the buffer size of the server process */
#define DATA "Loud and clear."	/* temporary constant until ready to send interactive replies to server */

/* prototypes for later function implementations */
void pdie(const char*);
void die(const char*);

/**************************************************************************************
 * main --- can't do without it
 *************************************************************************************/
int main(void) {
  int sock;			/* fd for main socket */
  int msgsock;			/* fd from accept return */
  struct sockaddr_in server;	/* socket struct for the server connection */
  struct sockaddr_in client;	/* socket struct for the client connection */
  int clientLen;		/* returned length of client from accept() call */
  int rval;			/* return value from read() call */
  char buf[BUFFER_SIZE];	/* the receive buffer used by server */


  /* For an explanation of the socket() call see the appendix */
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    pdie("Server opening stream socket");

  /* For an explanation of the bind() call see the appendix */
  bzero((char*)&server, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons(SERVER_PORT);
  if (bind(sock, (struct sockaddr *) &server, sizeof(server)))
    pdie("Server binding stream socket");

  /* ntohs - convert from network to host byte ordering see appendix at eof */
  printf("Socket has port %hu\n", ntohs(server.sin_port));

  /* set the listen queue to the maximum of 5 */
  /* for explanation of listen() call see the appendix */
  listen(sock, 5);

  /* Now enter the continuous server loop
   * Wait for the client connections */
  while (TRUE) {
    clientLen = sizeof(client);

    /* for explanation of accept() call see the appendix */
    if ((msgsock = accept(sock, (struct sockaddr*) &client, &clientLen)) == -1)
      pdie("Server Accept");
    else {
      /* Print information about the client */
      if (clientLen != sizeof(client))
      pdie("Server Accept overwrote socaddr structure");

      printf("Client IP: %s\n", inet_ntoa(client.sin_addr));
      printf("Client port: %hu\n", ntohs(client.sin_port));

      /* Next we read data from the client until it closes the connection */
      do {
        /* Prepare the read buffer and read */
        bzero(buf, sizeof(buf));
	/* for explanation of the write() call see the appendix */
        if ((rval = read(msgsock, buf, BUFFER_SIZE)) < 0)
          pdie("Server reading stream message");

        /* Test if client has closed the connection */
        if (rval == 0)
          fprintf(stderr, "Server ending connection after client close\n");
        else
          printf("S: %s\n", buf);

        /* Write back to the client to say hey I got it */
	/* for an explanation of the write() call see the appendix */
        if (write(msgsock, DATA, sizeof(DATA))  < 0)
          pdie("Server writing on stream socket to client");

      } while (rval != 0);
    }	/* close of the valid msg else */

    close(msgsock);
  }

  exit(0);

}

/**************************************************************************************
 * pdie --- Call perror() to figure out what went wrong and then die
 *************************************************************************************/
void pdie(const char* msg) {
  perror(msg);
  exit(1);
}

/**************************************************************************************
 * die --- print a error message and die
 *************************************************************************************/
void die(const char* msg) {
  fputs(msg, stderr);
  fputc('\n', stderr);
  exit(1);
}

/* Appendix:

Obtained from Tom Kelliher's introduction to socket programming, http://www.andrew.cmu.edu/~kevinm/sockets.html
Java to C++ tutorial at http://www.cs.sun.ac.za/~rdodds/RW354/C++/brown.edu.course.cs123/javatoc.html

 ---------------------------------------------------------------------------------------
 socket() call details:
 Open a socket using the socket call. But don't bind it yet. The type is Internet TCP.

 #include <sys/types.h>
 #include <sys/socket.h>

 int socket(int domain, int type, int protocol);

 Used to create an unamed socket. Must bind or connect.
 Returns a socket descriptor (small positive int). Returns -1 on error.
 domain:
   * AF_UNIX --- UNIX domain protocols.
   * AF_INET --- Internet domain protocols.
   * ...
 type:
   * SOCK_STREAM --- TCP protocol.
   * SOCK_DGRAM --- UDP protocol.
   * SOCK_RAW --- IP protocol.
   * ...

 protocol: set to 0.

 Typical call:
 int sock;
 if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
   die();

 ---------------------------------------------------------------------------------------
 bind() call details:
 Now we get ready to bind. Permit any connections from any client to our SERVER_PORT.
 Alternatively you can use a service name. See the TCPechod.c and TCPecho.c examples.

 #include <sys/types.h>
 #include <sys/socket.h>

 int bind(int sd, const struct sockaddr *name, int namelen);

 Assigns a name (port, etc.) to a socket.
 Returns 0 if successful, otherwise -1 and look in errno.
 sd: socket descriptor.

 name:
   * Pointer to a struct sockaddr_in for Internet sockets.
   * Cast to struct sockaddr *.
   *

   // Socket address, internet style.
   struct sockaddr_in {
      u_char   sin_len;
      u_char   sin_family;   	// AF_INET
      u_short  sin_port;     	// 16 bit port number
      struct   in_addr sin_addr;  	// IP address
      char  sin_zero[8];
   };

 For a server:
   sin_port --- desired listen port. Gt 5000.
   sin_addr --- another struct. Where we're willing to accept connections from.
   namelen: sizeof name structure.

 Typical call:
 struct sockaddr_in server;
 bzero((char *) &server, sizeof(server));
 server.sin_family = AF_INET;
 server.sin_addr.s_addr = INADDR_ANY;
 server.sin_port = htons(SERVER_PORT);
 if (bind(sock, (struct sockaddr *) &server, sizeof(server)))
   die();

 ---------------------------------------------------------------------------------------
 listen() call details:
 Next we signal we are ready to accept connections

 #include <sys/types.h>
 #include <sys/socket.h>

 int listen(int sd, int backlog);
	
 Announce willingness to accept connections to socket and a maximum queue length.
 Returns 0 on success, otherwise -1.
 sd: socket descriptor.
 backlog: max size of queue. Maximum is 5.
	
 Typical call:
 int sock;
 listen(sock, 5);

 ---------------------------------------------------------------------------------------
 accept() call details
 Next we use accept to receive connections

 #include <sys/types.h>
 #include <sys/socket.h>

 int accept(int sd, struct sockaddr *addr, int *addrlen);

 Extract first connection request on queue; blocking if queue is empty.
 Returns -1 on error, otherwise a non-negative descriptor to use for socket I/O ( read() or write()).
 sd: socket descriptor.
 addr:
   * Pointer to a struct sockaddr_in for Internet sockets.
   * Cast to struct sockaddr *.
   * sin_port --- client port.
   * sin_addr --- client IP address.
 addrlen: addressof sizeof addr structure.

 Typical call:
 struct sockaddr_in client;
 int msgsock, sock, clientLen;
 clientLen = sizeof(client);
 if ((msgsock = accept(sock, (struct sockaddr *) &client, &clientLen)) == -1)
   die();
 else {
   if (clientLen != sizeof(client))
     die();

 printf("Client IP: %s\n", inet_ntoa(client.sin_addr));
 printf("Client Port: %hu\n", ntohs(client.sin_port));

 ---------------------------------------------------------------------------------------
 read() call details:

 #include <unistd.h>
 ssize_t read(int sd, void* buf, size_t nbytes);

 Read at most nbytes bytes into buf from sd.
 Returns -1 on error, 0 on EOF (connection closed), or the actual number of bytes read.
 sd: socket descriptor.
 buf: addressof char buffer.
 nbytes: sizeof buf.

 Typical call:
 char buf[BUFFER_SIZE];
 int rval, msgsock;

 bzero(buf, BUFFER_SIZE);
 if ((rval = read(msgsock, buf, BUFFER_SIZE)) < 0)
   die();

 ---------------------------------------------------------------------------------------
 write() call details:

 #include <unistd.h>

 ssize_t write(int sd, const void *buf, size_t nbytes);
 Attempts to write nbytes from buf to sd.
 Returns -1 on error or the number of bytes actually written.
 Arguments similar to read().

 ---------------------------------------------------------------------------------------
 HTONS() -- TRANSLATE AN UNSIGNED SHORT INTEGER INTO NETWORK BYTE ORDER
 (c) Copyright IBM Corporation 1995, 1998

   #include <sys/types.h>
   #include <arpa/inet.h>

   unsigned short htons(unsigned short a);


 Purpose

 Use the htons() call to translate an unsigned short integer from host byte
 order to network byte order.

 Parameters
 
 a           The unsigned short integer to be converted to network byte order.
 
 Description
 
 The htons() call translates an unsigned short integer from host byte order to
 network byte order.  It is implemented as a macro, because on System/390
 platforms, host byte order and network byte order are the same.
 
 Return Values 
 
 Returns the translated unsigned short integer.
 ---------------------------------------------------------------------------------------

 NTOHS() -- TRANSLATE AN UNSIGNED SHORT INTEGER INTO HOST BYTE ORDER
 (c) Copyright IBM Corporation 1995, 1998
 
   #include <sys/types.h>
   #include <arpa/inet.h>

   unsigned short ntohs(unsigned short a);
 
 
 Purpose 
 
 Use the ntohs() call to translate an unsigned short integer from network byte
 order to host byte order.

 Parameters

 a           The unsigned short integer to be converted host byte order.

 Description

 The ntohs() call translates an unsigned short integer from network byte order
 to host byte order.  It is implemented as a macro, because on System/390
 platforms, host byte order and network byte order are the same.
 
 Return Values

 Returns the translated unsigned short integer.  No errors can be encountered.
 ---------------------------------------------------------------------------------------
 */
