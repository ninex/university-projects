import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Bespreking extends JFrame
{
  private Queries queries;  
  private int gp_ID;
  private JLabel header,naam,id,woonadres,posadres,epos,tel,begin_datum,eind_datum,error;
  private JLabel[] verblyf;
  private JTextField i_naam,i_id,i_woonadres,i_posadres,i_epos,i_tel/*,i_dd,i_mm,i_yy,i_dd2,i_mm2,i_yy2*/;
  private JTextField[] i_verblyf;
  private JButton bespreek;
  private JComboBox i_dd,i_mm,i_yy,i_dd2,i_mm2,i_yy2;
  private java.sql.Date begin,einde;
  private int[] verblyf_id;
  
  public Bespreking(Queries queries)
  {
    this.queries = queries;
    Font f = new Font(null,1,16);
    verblyf = new JLabel[queries.aantalFasiliteite()];
    i_verblyf = new JTextField[queries.aantalFasiliteite()];
    verblyf_id = new int[queries.aantalFasiliteite()];
    Container contentPane = getContentPane();
    contentPane.setLayout(null);

    //create content
    header = new JLabel();
    naam = new JLabel("Naam en Van");
    id = new JLabel("ID nr");
    woonadres = new JLabel("Adres");
    posadres = new JLabel("Pos Adres");
    epos = new JLabel("E-posadres");
    tel = new JLabel("Telefoon nr");
    begin_datum = new JLabel("Tydperk vanaf");
    eind_datum = new JLabel("tot");
    error = new JLabel("<html><font color=red>Please fill in required fields</font>");

    i_naam = new JTextField(300);
    i_id = new JTextField(300);
    i_woonadres = new JTextField(300);
    i_posadres = new JTextField(300);
    i_epos = new JTextField(300);
    i_tel = new JTextField(300);
    /*i_dd = new JTextField(2);
    i_mm = new JTextField(2);
    i_yy = new JTextField(4);
    i_dd2 = new JTextField(2);
    i_mm2 = new JTextField(2);
    i_yy2 = new JTextField(4);*/
    String[] day = { "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
    String[] month = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String[] year = {"2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014"};
    i_dd = new JComboBox(day);
    i_mm = new JComboBox(month);
    i_yy = new JComboBox(year);
    i_dd2 = new JComboBox(day);
    i_mm2 = new JComboBox(month);
    i_yy2 = new JComboBox(year);

    bespreek = new JButton("Bespreek");

    
    //and add to window
    contentPane.add(header);
    contentPane.add(naam);
    contentPane.add(id);
    contentPane.add(woonadres);
    contentPane.add(posadres);
    contentPane.add(epos);
    contentPane.add(tel);
    contentPane.add(begin_datum);
    contentPane.add(eind_datum);    
    contentPane.add(i_naam);
    contentPane.add(i_id);
    contentPane.add(i_woonadres);
    contentPane.add(i_posadres);
    contentPane.add(i_epos);
    contentPane.add(i_tel);
    contentPane.add(i_dd);
    contentPane.add(i_mm);
    contentPane.add(i_yy);
    contentPane.add(i_dd2);
    contentPane.add(i_mm2);
    contentPane.add(i_yy2);
    contentPane.add(bespreek);
    contentPane.add(error);

    //pre-setup
    
    header.setFont(f);

    //sit ons content op die regte posisie
    header.setBounds(60, 5, 400, 30);
    naam.setBounds(5, 30, 240, 20);
    id.setBounds(5, 50, 240, 20);
    woonadres.setBounds(5, 70, 240, 20);
    posadres.setBounds(5, 90, 240, 20);
    epos.setBounds(5, 110, 240, 20);
    tel.setBounds(5, 130, 240, 20);
    begin_datum.setBounds(5, 160, 240, 20);
    eind_datum.setBounds(75, 190, 240, 20);
    error.setBounds(5,280,360,60);

    i_naam.setBounds(120,30,240,20);
    i_id.setBounds(120, 50, 240, 20);
    i_woonadres.setBounds(120, 70, 240, 20);
    i_posadres.setBounds(120, 90, 240, 20);
    i_epos.setBounds(120, 110, 240, 20);
    i_tel.setBounds(120, 130, 240, 20);
    i_dd.setBounds(120,160,50,20);
    i_mm.setBounds(170,160,54,20);
    i_yy.setBounds(224,160,60,20);
    i_dd2.setBounds(120,190,50,20);
    i_mm2.setBounds(170,190,54,20);
    i_yy2.setBounds(224,190,60,20);

    bespreek.setBounds(280,330,100,25);
    
    for (int i=0;i<queries.aantalFasiliteite();i++)
    {
      verblyf[i] = new JLabel();
      contentPane.add(verblyf[i]);
      verblyf[i].setBounds(5,220+(i*20),240,20);
      i_verblyf[i] = new JTextField("0",1);
      contentPane.add(i_verblyf[i]);
      i_verblyf[i].setBounds(120,220+(i*20),30,20);
    }
    
    bespreek.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        //check of alles ingevul is
        error.setText("<html><font color=red>Please fill in ");
        if (i_naam.getText().equals("") || i_naam.getText().equals("*required"))
        {
          error.setVisible(true);
          error.setText(error.getText() + "naam");
          i_naam.setText("*required");
        }
        if (i_id.getText().equals("")|| i_id.getText().equals("*required"))
        {
          error.setVisible(true);
          if (!(error.getText().equals("<html><font color=red>Please fill in ")))
          {
            error.setText(error.getText()+" ,");
          }
          error.setText(error.getText() + "id");
          i_id.setText("*required");
        }
        if (i_woonadres.getText().equals("")|| i_woonadres.getText().equals("*required"))
        {
          error.setVisible(true);
          if (!(error.getText().equals("<html><font color=red>Please fill in ")))
          {
            error.setText(error.getText()+" ,");
          }
          error.setText(error.getText() + "adres");
          i_woonadres.setText("*required");
        }
        if (i_tel.getText().equals("")|| i_tel.getText().equals("*required"))
        {
          error.setVisible(true);
          if (!(error.getText().equals("<html><font color=red>Please fill in ")))
          {
            error.setText(error.getText()+" ,");
          }
          error.setText(error.getText() + "telefoon nr");
          i_tel.setText("*required");
        }
        //check of korrekte datums ingevul is
        if (
        ((i_mm.getSelectedItem().equals("Apr")) && (i_dd.getSelectedItem().equals("31")) )||
        ((i_mm.getSelectedItem().equals("Jun")) && (i_dd.getSelectedItem().equals("31")) )||
        ((i_mm.getSelectedItem().equals("Sep")) && (i_dd.getSelectedItem().equals("31")) )||
        ((i_mm.getSelectedItem().equals("Nov")) && (i_dd.getSelectedItem().equals("31")) )||
        ((i_mm2.getSelectedItem().equals("Apr")) && (i_dd2.getSelectedItem().equals("31")) )||
        ((i_mm2.getSelectedItem().equals("Jun")) && (i_dd2.getSelectedItem().equals("31")) )||
        ((i_mm2.getSelectedItem().equals("Sep")) && (i_dd2.getSelectedItem().equals("31")) )||
        ((i_mm2.getSelectedItem().equals("Nov")) && (i_dd2.getSelectedItem().equals("31")) )
        )
        {
          error.setVisible(true);
          if (!(error.getText().equals("<html><font color=red>Please fill in ")))
          {
            error.setText(error.getText()+" ,");
          }
          error.setText(error.getText() + "correct dates");
        }
        if (
        (( Integer.valueOf(i_yy.getSelectedItem().toString()).intValue() % 4 == 0) &&
        (i_mm.getSelectedItem().equals("Feb")) &&
        (Integer.valueOf(i_dd.getSelectedItem().toString()).intValue() > 29)) ||
        ((Integer.valueOf(i_yy.getSelectedItem().toString()).intValue() % 4 != 0) &&
        (i_mm.getSelectedItem().equals("Feb")) &&
        (Integer.valueOf(i_dd.getSelectedItem().toString()).intValue() > 28))
        ||
        (( Integer.valueOf(i_yy2.getSelectedItem().toString()).intValue() % 4 == 0) &&
        (i_mm2.getSelectedItem().equals("Feb")) &&
        (Integer.valueOf(i_dd2.getSelectedItem().toString()).intValue() > 29)) ||
        ((Integer.valueOf(i_yy2.getSelectedItem().toString()).intValue() % 4 != 0) &&
        (i_mm2.getSelectedItem().equals("Feb")) &&
        (Integer.valueOf(i_dd2.getSelectedItem().toString()).intValue() > 28))
        )
        {
          error.setVisible(true);
          if (!(error.getText().equals("<html><font color=red>Please fill in ")))
          {
            error.setText(error.getText()+" ,");
          }
          error.setText(error.getText() + "correct dates");
        }
	begin = java.sql.Date.valueOf(i_yy.getSelectedItem().toString()+"-"
        	+(i_mm.getSelectedIndex()+1)+"-"+i_dd.getSelectedItem().toString());
        einde = java.sql.Date.valueOf(i_yy2.getSelectedItem().toString()+"-"
        	+(i_mm2.getSelectedIndex()+1)+"-"+i_dd2.getSelectedItem().toString());

	isDatumsBeskikbaar();

        if (error.getText().equals("<html><font color=red>Please fill in "))
        {
          error.setVisible(false);
          bespreek();
        }else
        {
          error.setText(error.getText()+"</font>");
        }
      }
    });   
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        setVisible(false);
      }
    });
  }
  private void bespreek()
  {
    ResultSet rs = null;
    rs = SQLconnect.makeQuery("select * from toetsKontak where k_id = '"+i_id.getText()+"'");
    try
    {
    	if (!rs.next())
    	{ //nuwe kontakpersoon
	      rs = SQLconnect.makeQuery("insert into toetsKontak values('"+i_id.getText()
        	+"','"+i_naam.getText()+"','"+i_woonadres.getText()+"','"
	        +i_posadres.getText()+"','"+i_epos.getText()+"','"+i_tel.getText()+"');");
    	}else
        {
        //update kontak info
        	if (!(
                 (rs.getString("k_naam").equals(i_naam.getText())) &&
                 (rs.getString("k_adres").equals(i_woonadres.getText())) &&
                 (rs.getString("k_posadres").equals(i_posadres.getText())) &&
                 (rs.getString("k_epos").equals(i_epos.getText())) &&
                 (rs.getString("k_tel").equals(i_tel.getText()))
                 ))
                {
                  rs = SQLconnect.makeQuery("update toetsKontak set k_naam = '" +i_naam.getText()+
                  "', k_adres = '"+i_woonadres.getText()+"', k_posadres = '"+i_posadres.getText()+
                  "',k_epos = '"+i_epos.getText()+"',k_tel = '"+i_tel.getText()+
                  "' where k_id = '"+i_id.getText()+"'");
                }
        }
        String bnr = queries.volgende_Bnr();

         rs = SQLconnect.makeQuery("insert into toetsBespreking values('"+bnr+"','"+i_id.getText()+"','"
         	+begin+"','"+einde+"','"+gp_ID+"')");

        for (int i=0;i<queries.aantalFasiliteite();i++)
   	{
        	if ( Integer.valueOf(i_verblyf[i].getText()).intValue() != 0 )
                {
                	rs = SQLconnect.makeQuery("insert into toetsSlaap_plek values('"+bnr+"',"
                	+verblyf_id[i]+","
                	+Integer.valueOf(i_verblyf[i].getText()).intValue()+")");
                }
	}

    }catch (SQLException sqe)
    {}
    SQLconnect.close();

    this.setVisible(false);
  }

  private void isDatumsBeskikbaar()
  {
  	System.out.println("check datums");
  }

  public void beginBespreking(int gp_ID)
  {
    this.gp_ID = gp_ID;
    header.setText("Bespreek by "+ Queries.getPlaasNaam(gp_ID));
    i_naam.setText("");
    i_id.setText("");
    i_woonadres.setText("");
    i_posadres.setText("");
    i_epos.setText("");
    i_tel.setText("");
    /*i_dd.setText("");
    i_mm.setText("");
    i_yy.setText("");
    i_dd2.setText("");
    i_mm2.setText("");
    i_yy2.setText("");*/
    error.setVisible(false);
    queries.kryVerblyfInfo(gp_ID,verblyf,i_verblyf,verblyf_id);
  }
}   
