DROP TABLE
 Aktiwiteite,
 Bespreking,
 Dorp,
 Fasiliteite,
 Gasteplaas,
 Kontak,
 Slaap_plek,
 Tipe_Aktiwiteite,
 Verblyf_Fasiliteite CASCADE;

 
