import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class window extends JFrame
{
  private Queries queries;
  private boolean laidOut = false;
  //declare components for window
  private JButton b1,b2,b3;
  private JLabel t[];
  private JComboBox list;
  private int gp_ID,aantal_plase;
  private Bespreking myBespreking;

  //al die listeners wat my komponente moontlik kan he
  //van hieraf word alles beheer
  private void addMyListeners()
  {
    b1.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if (gp_ID > 1)
        {
          gp_ID--;
          Queries.vollePlaasInfo(gp_ID,t);
        }
      }
    });
    b2.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if (gp_ID < aantal_plase)
        {
          gp_ID++;
          Queries.vollePlaasInfo(gp_ID,t);
        }
      }
    });
    b3.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        myBespreking.beginBespreking(gp_ID);
        myBespreking.setVisible(true);        
      }
    });
    list.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        gp_ID = list.getSelectedIndex() + 1;
        Queries.vollePlaasInfo(gp_ID,t);
      }
    });
  }

  
  //constructor
  public window()
  {
    queries = new Queries();
    myBespreking = new Bespreking(queries);
    myBespreking.setTitle("Maak 'n bespreking");
    myBespreking.setSize(400,400);
    myBespreking.setResizable(false);
    //center on screen
    myBespreking.setLocationRelativeTo(null);
    
    Font f = new Font(null,1,24);
    t = new JLabel[12];
    gp_ID = 1;
    aantal_plase = queries.aantalPlase();
    
    Container contentPane = getContentPane();
    contentPane.setLayout(null);

    //create content
    b1 = new JButton("Vorige");
    b2 = new JButton("Volgende");
    b3 = new JButton("Maak Bespreking");
    t[0] = new JLabel();
    t[1] = new JLabel();
    t[2] = new JLabel("Aanliggende Dorpe:");
    t[3] = new JLabel();
    t[4] = new JLabel();
    t[5] = new JLabel("Aktiwiteite: ");
    t[6] = new JLabel();
    t[7] = new JLabel("Verblyf Fassiliteite: ");
    t[8] = new JLabel();
    t[9] = new JLabel();
    t[10] = new JLabel();
    t[11] = new JLabel();
    list = new JComboBox();
    //and add to window
    contentPane.add(b1);
    contentPane.add(b2);
    contentPane.add(b3);    
    for (int i=0;i<t.length;i++)
    {
      contentPane.add(t[i]);
    }
    contentPane.add(list);
    
    //pre-setup
    t[0].setFont(f);
    Queries.vollePlaasInfo(gp_ID,t);
    Queries.fillList(list);

    //neem borders en titlebar in ag
    Insets insets = contentPane.getInsets();

    //sit ons content op die regte posisie
    b1.setBounds(25 + insets.left, 5 + insets.top, 100, 20);
    b2.setBounds(500 + insets.left, 5 + insets.top, 100, 20);
    b3.setBounds(300 + insets.left, 5 + insets.top, 160, 20);
    t[0].setBounds(250 + insets.left, 20 + insets.top, 240, 30);
    t[1].setBounds(50 + insets.left, 60 + insets.top, 160, 20);
    t[2].setBounds(50 + insets.left, 100 + insets.top, 160 , 20);
    t[3].setBounds(210 + insets.left, 100 + insets.top, 160, 20);
    t[4].setBounds(210 + insets.left, 125 + insets.top, 160, 20);
    t[5].setBounds(50 + insets.left, 200 + insets.top, 160, 20);
    t[6].setBounds(50 + insets.left, 240 + insets.top, 400, 20);
    t[7].setBounds(50 + insets.left, 300 + insets.top, 160, 20);
    t[8].setBounds(50 + insets.left, 340 + insets.top, 160, 20);
    t[9].setBounds(50 + insets.left, 380 + insets.top, 160, 20);
    t[10].setBounds(50 + insets.left, 420 + insets.top, 160, 20);
    t[11].setBounds(50 + insets.left, 460 + insets.top, 160, 20);
    list.setBounds(25 + insets.left, 30 + insets.top, 200,25);
    //all die listeners
    addMyListeners();
    
    //sit 'n window listener by vir wanneer die user wil quit
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        System.exit(0);
      }
    });
  }
  
  public static void setup()
  {
    
    


    //maak 'n nuwe window
    window myWindow = new window();
    Insets insets = myWindow.getInsets();

    //stel sy title en grootte
    myWindow.setTitle("RW 242: Databasis projek");
    myWindow.setSize(640 + insets.left + insets.right, 540 + insets.top + insets.bottom);
    myWindow.setResizable(false);
    //center on screen
    myWindow.setLocationRelativeTo(null);
    //wys dit
    myWindow.setVisible(true);
  }
} 
