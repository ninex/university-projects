import javax.swing.*;
import java.sql.*;

public class Queries
{
  private int gp_aantal;
  private int f_aantal;
  private int[] verblyf;

  public Queries()
  {
    gp_aantal = stoorAantalPlase();
    f_aantal = stoorAantalFasiliteite();
    verblyf = new int[f_aantal];
  }

  public int aantalPlase()
  {
    return gp_aantal;
  }
  public int aantalFasiliteite()
  {
    return f_aantal;
  }
  private int stoorAantalPlase()
  {
    int count = 0;
    try
    {
      ResultSet rs = SQLconnect.makeQuery("Select count(*) from Gasteplaas");
      try
      {
        if (rs.next())
      {
        count = rs.getInt("count");
      }
      }catch (SQLException sqe)
      {}
    }catch (NullPointerException npe)
    {System.exit(0);}
    
    SQLconnect.close();
    return count;
  }

  private int stoorAantalFasiliteite()
  {
    int count = 0;
    try
    {
      ResultSet rs = SQLconnect.makeQuery("Select count(*) from fasiliteite");
      try
      {
        if (rs.next())
        {
          count = rs.getInt("count");
          
        }
      }catch (SQLException sqe)
      {System.out.println("ERROR");}
    }catch (NullPointerException npe)
    {System.out.println("ERROR");}

    SQLconnect.close();
    return count;
  }
  
  public static void fillList(JComboBox list)
  {
    list.removeAllItems();
    ResultSet rs = SQLconnect.makeQuery("Select gp_Naam from Gasteplaas");
    try
    {
      while (rs.next())
      {
        list.addItem(rs.getString("gp_Naam"));
      }
    }catch (SQLException sqe)
    {}
    SQLconnect.close();
  }
  
  public static String getPlaasNaam(int gp_ID)
  {
    String naam = "";
    ResultSet rs = SQLconnect.makeQuery("Select gp_Naam from Gasteplaas where gp_ID = "+gp_ID);
    try
    {
      if (rs.next())
      {
        naam = rs.getString("gp_Naam");
      }
    }catch (SQLException sqe)
    {}
    SQLconnect.close();
    return naam;
  }
  public void kryVerblyfInfo(int gp_ID,JLabel[] teks,JTextField[] i_teks,int[] verblyf_id)
  {
    for (int i=0;i<f_aantal;i++)
    {
      verblyf[i] = 0;
      teks[i].setText("");
      i_teks[i].setVisible(false);
    }
    
    ResultSet rs = SQLconnect.makeQuery("select f.f_id,f_tipe,vf_totaal,vf_beskikbaar from verblyf_fasiliteite vf,fasiliteite f where vf.f_id = f.f_id and gp_id = "+gp_ID);
    try
    {
      int i=0;
      while (rs.next())
      {
        verblyf[rs.getInt("f_id")-1] = rs.getInt("vf_beskikbaar");
        verblyf_id[i] = rs.getInt("f_id");
        teks[i].setText(rs.getString("f_tipe"));
        i_teks[i].setVisible(true);
        i_teks[i].setText("0");
        i++;
      }
    }catch (SQLException sqe)
    {System.out.println(sqe.getMessage());}
    SQLconnect.close();
    //return ret;
  }
  public static void vollePlaasInfo(int gp_ID,JLabel[] t)
  {

      String naam;
      String afstand;
     // if (rs.next())
     // {}


    //kry die plaas naam en Provinsie
    ResultSet rs = SQLconnect.makeQuery("SELECT gp_Naam,gp_Provinsie FROM Gasteplaas WHERE gp_ID = "+ gp_ID);
    try
    {
      if (rs.next())
      {
        t[0].setText(rs.getString("gp_Naam"));
        t[1].setText("Provinsie :" + rs.getString("gp_Provinsie"));
      }else
      {
        t[0].setText("");
        t[1].setText("");
      }
    }catch (SQLException sqe)
    {}
    
    //kry die aanliggende dorpe en hulle afstande
    rs = SQLconnect.makeQuery("Select d_Naam,d_afstand from Dorp where gp_ID = "+ gp_ID);
    try
    {
      if (rs.next())
      {
        t[3].setText(rs.getString("d_Naam") + " " + rs.getString("d_afstand")+"km");
      }else
      {
        t[3].setText("");
      }

      if (rs.next())
      {
        t[4].setText(rs.getString("d_Naam") + " " + rs.getString("d_afstand")+"km");
      }else
      {
        t[4].setText("");
      }
    }catch (SQLException sqe)
    {}
    //kry die lys van aktiwiteite wat aangebied word
    rs = SQLconnect.makeQuery("SELECT takw.akw_tipe FROM Aktiwiteite akw ,Tipe_Aktiwiteite takw WHERE gp_ID = "+ gp_ID +" AND takw.akw_ID = akw.akw_ID");
    try
    {
      String out = "";
      if (rs.next())
      {
        out = rs.getString("akw_tipe");
      }
      while (rs.next())
      {
        out = out +", "+rs.getString("akw_tipe");
      }
      t[6].setText(out);
    }catch (SQLException sqe)
    {}
    //kry die verblyf fasiliteite wat beskikbaar is
    rs = SQLconnect.makeQuery("SELECT vf.vf_totaal, f.f_tipe FROM Verblyf_Fasiliteite vf, Fasiliteite f WHERE gp_ID = "+ gp_ID +" AND vf.f_ID = f.f_ID");
    try
    {
      for (int i=0;i<4;i++)
      {
        if (rs.next())
        {
          t[8+i].setText(rs.getString("f_tipe")+":  "+rs.getString("vf_totaal"));
        }else
        {
          t[8+i].setText("");
        }
      }
    }catch (SQLException sqe)
    {}
    SQLconnect.close();
  }
  public static String volgende_Bnr()
  {
  	int bnr;
        String s_bnr = "B001";
        char[] out = new char[4];
	ResultSet rs = SQLconnect.makeQuery("Select max(b_id) from toetsBespreking");
        try
        {
	try
        {
        	if ((rs.next()) && (rs.getString("max") != null))
                {
                	s_bnr = rs.getString("max");
                        //s_bnr = s_bnr.substring(1);
                        if (s_bnr.charAt(3) == '9')
                        {
                        	out[3] = '0';
                                if (s_bnr.charAt(2) == '9')
                                {
                                	out[2] = '0';
                                        if (s_bnr.charAt(1) == '9')
                                        {
                                        	out[1] = '0';
                                        }else
                                        {
                                        	bnr = Integer.valueOf(String.valueOf(s_bnr.charAt(1))).intValue() + 1;
                                                out[1] = (String.valueOf(bnr)).charAt(0);
                                        }
                                }else
                                {
                                	out[1] = s_bnr.charAt(1);
                                	bnr = Integer.valueOf(String.valueOf(s_bnr.charAt(2))).intValue() + 1;
                                        out[2] = (String.valueOf(bnr)).charAt(0);
                                }
                        }else
                        {
                        	out[1] = s_bnr.charAt(1);
                                out[2] = s_bnr.charAt(2);
                        	bnr = Integer.valueOf(String.valueOf(s_bnr.charAt(3))).intValue() + 1;
                                out[3] = (String.valueOf(bnr)).charAt(0);
                        }
                        out[0] = 'B';
                        s_bnr = String.valueOf(out);
                         System.out.println(s_bnr);
                }
        }catch (SQLException sqe)
        {}
        }catch (NullPointerException npe)
        {s_bnr = "B001";}
	return s_bnr;
  }
}
