import java.sql.*;
public class toets
{

//=========================================================================================  
  public static void main(String[] args)
  {
    //toets_SQL();
    window.setup();
    //dr.teken();
  }
}