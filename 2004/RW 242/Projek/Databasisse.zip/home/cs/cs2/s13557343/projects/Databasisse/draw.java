import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class draw
{
  private void setupWindow()
  {
    //kry 'n instance vir ons hoof window
    JFrame frame = new JFrame("RW 242: Databasis projek");
    
  }
/*      private int numClicks = 0;


      
  public void teken()
  {

    JFrame frame = new JFrame("RW 242 Projek");
     //...create the components to go into the frame...
     //...stick them in a container named contents...
    JPanel pane = new JPanel();
    pane.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
    pane.setLayout(new GridLayout(0, 1)); 
    JButton button = new JButton("WHAT UP MOTHERFUCKER");
    final JLabel label = new JLabel("otter vet");
    pane.add(label);
    pane.add(button);
    pane.setBorder(BorderFactory.createEmptyBorder(
                                30, //top
                                30, //left
                                10, //bottom
                                30) //right
                                );
    class TableModel extends AbstractTableModel
    {
          final String[] columnNames = {"gp_ID",
                                          "d_Naam",
                                          "d__Afstand"};
          public int getColumnCount() { return 10; }
          public int getRowCount() { return 10;}
          public Object getValueAt(int row, int col) { return new Integer(row*col); }
          public void setValueAt(Object value, int row, int col) {
            if (DEBUG) {
                System.out.println("Setting value at " + row + "," + col
                                   + " to " + value
                                   + " (an instance of "
                                   + value.getClass() + ")");
            }

            if (data[0][col] instanceof Integer
                    && !(value instanceof Integer)) {
                //With JFC/Swing 1.1 and JDK 1.2, we need to create
                //an Integer from the value; otherwise, the column
                //switches to contain Strings.  Starting with v 1.3,
                //the table automatically converts value to an Integer,
                //so you only need the code in the 'else' part of this
                //'if' block.
                //XXX: See TableEditDemo.java for a better solution!!!
                try {
                    data[row][col] = new Integer(value.toString());
                    fireTableCellUpdated(row, col);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(TableDemo.this,
                        "The \"" + getColumnName(col)
                        + "\" column accepts only integer values.");
                }
            } else {
                data[row][col] = value;
                fireTableCellUpdated(row, col);
            }
        }
      };
    TableModel dataModel = new TableModel() ;

    
    String[] columnNames = {"gp_ID",
                        "d_Naam",
                        "d__Afstand"};
    final JTable table = new JTable(dataModel);
    ResultSet rs = SQLconnect.makeQuery("Select * from Dorp where gp_ID = '6'");
    //data = new Object[200][3];
    try
    {
      int j = 0;
      while (rs.next())
      {
        // retrieve and print the values for the current row
        String i = rs.getString("gp_ID");
        String s = rs.getString("d_Naam");
        String f = rs.getString("d_afstand");
        //data[j][0] = i;
        //data[j][1] = s;
        //data[j][2] = f;
        j++;        
        //System.out.println("ROW = " + i + " " + s + " " + f);
      }
    }catch (SQLException sqe)
    {
      System.out.println(sqe.getMessage());
    }
    SQLconnect.close();
       
    pane.add(table);

    frame.getContentPane().add(pane);


    //Finish setting up the frame, and show it.
    frame.addWindowListener(new WindowAdapter()
    {
       public void windowClosing(WindowEvent e)
       {
        System.exit(0);
       }
    });
    button.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e) {
      numClicks++;
      label.setText("MUF'THER" + numClicks);
    }
    });
    frame.pack();
    frame.setVisible(true);
  }*/
} 
