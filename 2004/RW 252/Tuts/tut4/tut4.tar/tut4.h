#ifndef TUT4_H
#define TUT4_H

extern void addf(float a, float b, float *x);

#endif
