public class col{
	float r,g,b;
	int x,y;
	public col(float r,float g,float b,int x, int y){
		this.r = r;
		this.g = g;
		this.b = b;
		this.x = x;
		this.y = y;
	}
	public col(float r,float g,float b){
		this.r = r;
		this.g = g;
		this.b = b;
	}
}