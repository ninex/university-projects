!# /usr/bin/perl -w

scalar $i;
scalar $j;
scalar $path;


for ($path=38; $path<=40; $path++) {

  system "mkdir /floppy/$path";

  for ($i=1; $i<10; $i++) {
    $j = $path . '/lowres16/' . $i . 'lr.gif';
    system "cp $j /floppy/$path/";
    print "copied $j/n";
  }
}

die "OK";
