!# /usr/bin/perl -w

scalar $i;
scalar $j;
scalar $path;


for ($path=1; $path<=40; $path++) {
  for ($i=1; $i<10; $i++) {
    $j = $path . '/lowres16/' . $i . 'lr';
    system "dmconvert -f gif $j.ppm $j.gif";
  }
}

die "OK";
