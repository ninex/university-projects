//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Loony.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SKULLYTYPE                  129
#define IDD_BONE_INFO                   132
#define IDD_CARTOON_SET                 132
#define IDD_SPEED                       133
#define IDD_SIMPROP                     134
#define IDD_ADDSPHERE                   138
#define IDD_WEIGHT                      164
#define IDC_BONE_NAME                   1001
#define IDC_SIL_WIDTH                   1001
#define IDC_TRANS_X                     1002
#define IDC_SIL_RED                     1002
#define IDC_TRANS_Y                     1003
#define IDC_PLAYBACK_SPEED              1003
#define IDC_SIL_GREEN                   1003
#define IDC_TRANS_Z                     1004
#define IDC_GRAVX                       1004
#define IDC_XPOS                        1004
#define IDC_SIL_BLUE                    1004
#define IDC_ROT_X                       1005
#define IDC_GRAVY                       1005
#define IDC_YPOS                        1005
#define IDC_LIGHT_X                     1005
#define IDC_ROT_Y                       1006
#define IDC_GRAVZ                       1006
#define IDC_ZPOS                        1006
#define IDC_LIGHT_Y                     1006
#define IDC_ROT_Z                       1007
#define IDC_COEFREST                    1007
#define IDC_RADIUS                      1007
#define IDC_LIGHT_Z                     1007
#define IDC_MIN_X                       1008
#define IDC_SPRINGCONST                 1008
#define IDC_MAX_X                       1009
#define IDC_Damping                     1009
#define IDC_MIN_Y                       1010
#define IDC_SPRINGDAMP                  1010
#define IDC_MAX_Y                       1011
#define IDC_USERFORCEMAG                1011
#define IDC_MIN_Z                       1012
#define IDC_MAX_Z                       1013
#define IDC_BSPHERE                     1014
#define IDC_BONEWEIGHT                  1014
#define IDC_DOF_ACTIVE                  1015
#define IDC_SCRIPTLIST                  1232
#define ID_PLAY_FORWARD                 32777
#define ID_FORWARD_FRAME                32778
#define ID_STOP                         32779
#define ID_BACK_FRAME                   32780
#define ID_PLAY_BACK                    32781
#define ID_ADD_BONE                     32782
#define ID_DELETE_BONE                  32783
#define ID_VIEW_RESETSKELETON           32784
#define ID_FILE_LOADANIM                32785
#define ID_ANIMATION_PLAYBACKSPEED      32788
#define ID_WHICHOGL                     32789
#define ID_SKELETON_RESETSKELETON       32790
#define ID_VIEW_OUTLINE                 32791
#define ID_CARTOON_SETTINGS             32791
#define ID_FILE_OPENCHARACTERMESH       32792
#define ID_FILE_OPENOBJECTMESH          32792
#define ID_VIEW_VIEWSKELETON            32793
#define ID_VIEW_VIEWPARTICLES           32794
#define ID_FILE_OPENPARTICLESYSTEM      32795
#define ID_FILE_SAVE_PART               32796
#define ID_MODEL_REPLACEMESH            32798
#define ID_MODEL_REPLACETEXTURE         32799
#define ID_VIEW_DRAWDEFORMED            32800
#define ID_SKELETON_SETRESTPOSE         32801
#define ID_SKELETON_SETBONEWEIGHTS      32802
#define ID_FILE_OPENWEIGHT              32803
#define ID_SKELETON_CLEARSELECTEDWEIGHTS 32804
#define ID_CARTOON_ANTIALIAS            32805
#define ID_CARTOON_DRAWSILHOUETTE       32806
#define ID_INDICATOR_FRAME              59142
#define ID_INDICATOR_FRAME2             59143

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
