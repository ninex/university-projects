/*
 * PlaneLab include file.
 *
 */

#ifndef _PLANETLAB_H_
#define _PLANETLAB_H_


#define IPPROTO_ICMP_UDP 117
#define IPPROTO_ICMP_TCP 106


#endif /* _PLANETLAB_H_ */
