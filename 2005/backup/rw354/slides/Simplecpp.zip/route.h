/* -*-	Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
 * Copyright (c) 1991-1994 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and the Network Research Group at
 *	Lawrence Berkeley Laboratory.
 * 4. Neither the name of the University nor of the Laboratory may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Routing code for general topologies based on min-cost routing algorithm in
 * Bertsekas' book.  Written originally by S. Keshav, 7/18/88
 * (his work covered by identical UC Copyright)
 */

#ifndef ns_route_h
#define ns_route_h

#include "mpr.h"        

#define INFINITY	0x3fff
#define INDEX(i, j, N) ((N) * (i) + (j))        

/*** definitions for hierarchical routing support 
right now implemented for 3 levels of hierarchy --> should
be able to extend it for n levels of hierarchy in the future ***/

#define HIER_LEVEL	3
#define N_N_INDEX(i, j, a, b, c)	(((i) * (a+b+c)) + (j))
#define N_C_INDEX(i, j, a, b, c)	(((i) * (a+b+c)) + (a+j))
#define N_D_INDEX(i, j, a, b, c)	(((i) * (a+b+c)) + (a+(b-1)+j))
#define C_C_INDEX(i, j, a, b, c)	(((a+i) * (a+b+c)) + (a+j))
#define C_D_INDEX(i, j, a, b, c)	(((a+i) * (a+b+c)) + (a+(b-1)+j))
#define D_D_INDEX(i, j, a, b, c)	(((a+(b-1)+i) * (a+b+c)) + (a+(b-1)+j))


class RouteLogic : public TclObject {
public:
	RouteLogic();
	~RouteLogic();
	int command(int argc, const char*const* argv);
	int lookup_flat(char* asrc, char* adst, int&result);
	static void ns_strtok(char *addr, int *addrstr);
	int lookup_hier(char* asrc, char* adst, int&result);
//---------------------------------------------------------------
        int lookup_ilabel_Lib(int i, int j, int&result);
        int lookup_olabel_Lib(int i, int j, int&result);
        int lookup_nh_Lib(int i, int j, int&result);
//----------------------------------------------------------------
protected:

	void check(int);
	void alloc(int n);
	void insert(int src, int dst, int cost);
	void reset(int src, int dst);
	void compute_routes();
   int Label(int i, int j, int nh);
   void delete_LspSet(int s, int t);
   void init_LspSet(void);
   void init_length(void);
   void init_flow(void);
   void set_initial_flows(int s, int t);
   void adjust_capacity(void);
   void adjust_link(int s, int t);
   void adjust_metrics(void);
   void init_links(void);
   void read_net(void);
   void read_flow(void);
   void print_net(void);
   void print_routes(void);
   void Kdsp(int s, int t);
   void Kdsps(int s, int t);
   void build_lsp_sets(void);
   void hybrid_routing(void);
   void multipath_routing(void);
   int delta_load_balance(int s, int t);
   void equal_cost_routing(void);
   void equal_cost_balance(int s, int t);
   void get_feasible_flows(void);
   int find_feasible_flows(void);
   void weigth_cost_routing(void);
   void weigth_load_balance(int s, int t);
   void compute_lsp_flow(int s, int t);
   void assign_flow_lsp(int s, int t, double f);
   void print_lsps(void);
   void print_link_usage(void);
   void print_lsp_set(int s, int t);
   void record(int s, int t);
   void set_data(int s, int t);
   void install_lsps(int s, int t);
   void set_hash();
   void set_hash(int s, int t);
   void compute_lsps(void);
   void build_lsps(void);
   double Delay(void);
//--------------------------------------------------------------------------

	/**** Hierarchical routing support ****/

	void hier_check(int index);
	void hier_alloc(int size);
	void hier_init(void);
	void str2address(const char*const* address, int *src, int *dst);
	void get_address(char * target, int next_hop, int index, int d, int size, int *src);
	void hier_insert(int *src, int *dst, int cost);
	void hier_reset(int *src, int *dst);
	void hier_compute();
	void hier_compute_routes(int index, int d);

	/* Debugging print functions */
	void hier_print_hadj();
	void hier_print_route();
	
int END;      // END is used to test the convergence to a minimum delay 
int FEASIBLE; // (END == FEASIBLE) when a set of feasible flows is obtained
int YES;	  // (END == YES) when the flows converge to the minimum
double Delay_;
double epsilon;
double Treq;
double NewDelay_;
double * adj_;
int * tadj_;
int * util_;
int * path;
int * links;
int * Lspn;
int * Lspl;
int * route_;
double * lslack_;
double * slack_;
double * length_;
double * delay_;
double * sderiv_;
double * caps_;
double * lcaps_;
double * flow_;
double * req_;
int    * link_;
int n1;
lsp_set * Lsp_set;
lsp_entry * Lsp_entry;
lsp_entry * Previous;
lsp_entry * First;
lib * LIB;
lib * bk;
int  Nevents ;
//int  INFINITY;
int  r; 
int  Lsp_id; 
int  LspSet_np;
double  Lsp_fl;
int  nb; 
int  Nnodes, Nlinks, max, min, Nservices, Model, Npackets;
int  ind, m, s, t, i, j, b,nfeasible,feasible;
int step;
//---------------------------------------------------------------------
	int size_, maxnode_;
	int	**hadj_;
	int	**hroute_;
	int	*hsize_;
	int	*cluster_size_;		/* no. of nodes/cluster/domain */
	char	***hconnect_;		/* holds the connectivity info --> address of target */
	int	level_;
	int	*C_;                    /* no. of clusters/domain */
	int	D_,			/* total no. of domains */
		Cmax_;			/* max value of C_ for initialization purpose */
	
};
#endif
