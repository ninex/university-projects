/*
 * File: Header File for MPLS multipath routing
 * Author: Antoine Bagula (bagula@cs.sun.ac.za), March 2000
 *
 */


#ifndef market_h
#define market_h

struct l_entry {
	double * entry;		// pointer to the path 
};
#endif
