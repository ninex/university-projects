/*
 * File: Header File for the Label Information Base used in Mpls minimum cost 
 * label  distribution
 * Author: Antoine Bagula (bagula@cs.sun.ac.za), March 2000
 *
 */


#ifndef ns_mpls_h
#define ns_mpls_h

struct lib {
  int Ilabel;
  int Olabel; 
  int Oport;
  int Oqueue;                                        
  int Nhop;         
  lib * Backup;         
};

struct Nodes {
  int  id;    // Identity of that node
  int  lt[8]; // Length to other nodes
  int  ct[8]; // Costs of routes to other nodes;
  int  ur[8]; // Utilization rate on the routes to other nodes;
};

struct snt {
  int  id;    // Identity of that node
  int  TTL; // Time to Live
  int  Nhop; // Next hop
  int  ur; // utilization rate
  int cl ; // 
};
struct bpm {
  int  id;    // Identity of that node
  int  lt; // Length to its preferred alternate path
  int  lp; // Indicator of a loop in the path
  int  ur; // Utilization rate on its preferred alternate path;
  int  bur; // Utilization rate on the best alternate path;
  int  nh; // Next Hop from a bifurcation node                 
  double wt; // Weight of that path               
};
struct Packet {
  int  type;
  char pld[23]; 
  int * Hops;
  int label;
  int src;
  int dst;                                        
};

struct calendar {
  int  o;
  int d; 
  int nh;
  int ttl;
  int filled;
};

#endif

