#ifndef atmnode_h
#define atmnode_h
#include <math.h>

#include "object.h"
#include <fstream.h>
#include <string.h>
#include "atmaal.h"
#include "atmlink.h"

class ATMNetwork;
class ATMAgent;
/*
 * The parent class for all the nodes in a network. This includes ATM traffic
 * sources and the switches. It is derived from the NsObject and Handler
 * classes so that they can handle packets and also accept tcl commands
 */

class ATMNode : public NsObject, public Handler {
	public:
		ATMNode();
		ATMNode(int);	//Number of aal layers.
		~ATMNode();
		virtual void init_aal(int);
//		virtual int add_agent(ATMAgent*);

		inline void addr(int ad){addr_=ad;}
		inline int addr(){ return addr_;}
		inline void network(ATMNetwork* net){network_=net;};
		inline ATMNetwork* network(){return network_;};
		inline void add_route(int dst,ATMLink* l)
		{
			links_[dst]=l;
		}

		inline ATMLink* get_route(int dst)
		{
			return links_[dst];
		}

		void add_dummy_link(int);

		//Have to make this
		//virtual command(int argc, const char*const* argv);
		virtual void add_link(ATMLink *);
		//virtual void handle(Event* event);
	protected:
		ATMAal* aal;	//The aal layer
		int total_nodes;	//The total nodes in the atm network
		int no_links_;		//The number of links connected
		int addr_;		//This node's address
		ATMNetwork * network_;	//This node's network for handing
					//back packets and requesting for
				//resources in the network
		ATMLink ** links_;	//The list of the links going out
				//from this node. This does not include the
				//TCP links
		struct DummyLinks{
			int addr;	//The address of the external node
			int port;	//The switch port number
			DummyLinks* next;	
		};
		DummyLinks* dummy_;	//This is a list of dummy (external) 
			//links.
		int get_dummy_port(int);	
		int dummy_count;	//The number of dummy nodes attached
		int * port_table;	//The list of ports in this switch

};
#endif
