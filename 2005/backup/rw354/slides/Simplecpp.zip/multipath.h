/*
 * File: Header File for MPLS multipath routing
 * Author: Antoine Bagula (bagula@cs.sun.ac.za), March 2000
 *
 */


#ifndef ns_mpr_h
#define ns_mpr_h

struct lib {
  int Ilabel;
  int Olabel; 
  int Nhop;      
  int Oqueue;                                        
  int Oport;        
  lib * Backup;        
};

struct merge_set {
	int np;
	int * ptr;
};

struct state {
	int predecessor;
	double length;
	char label;
};

struct lp_entry {
	double inter;  		// interference on that path
	double slack;  		// slack between capacity and flow
	double util;  		// maximum link utilization
	double threshold;  	// path threshold
	double load;  		// traffic on this path
	double length;  	// length of this path
	double sderiv;  	// second derivative 
	double delta;  		// delta of this path
	double vband;   	// virtual bandwidth of this path
	double epsilon; 	// threshold for congestion avoidance
	int id;			// identity of this LP
	int nb;			// number of hops in that path
	int * nodes_ptr;	// pointer to the path 
 	lp_entry * next;	// pointer to next path
};

struct lp_set {
	int np; 		// Number of paths in the LP set
	int na; 		// Number of active paths in the LP set
	int id; 		// identity of the LP set
	double load;		// total traffic offered to this LP set
	lp_entry * entry;	// entry to the set of paths
};
struct bitstruct {
	unsigned Tipath:	1; // Topological interfering path
	unsigned Sipath:	1; // Selected interfering path
	unsigned Aipath:	1; // Active interfering path
};
struct Int {
	int Tiner; 		// Topological interference
	int Sinter; 		// Selective interference
	int Ainter;		// Active interference
	bitstruct * ipaths;	// entry to the set of interfering paths
};
#endif
