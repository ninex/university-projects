/*
 * File: Header File for MPLS multipath routing
 * Author: Antoine Bagula (bagula@cs.sun.ac.za), March 2000
 *
 */


#ifndef ns_mpr_h
#define ns_mpr_h

struct lib {
  int Ilabel;
  int Olabel; 
  int Nhop;      
  int Oqueue;                                        
  int Oport;        
  lib * Backup;        
};

struct lsp_entry {
	double length;
	double sderiv;
	double slack;
	double load;
	int id;
	int nb;
	int nh;
	int * nodes_ptr;
	int * links_ptr;
 	lsp_entry * next;
};

struct lsp_set {
	int nl; // Number of links in the Lsp set
	int np; // Number of paths in the Lsp set
	int id;
	double load;
	lsp_entry * entry;
};

#endif
