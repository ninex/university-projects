/*
 * File: Header File for a new 'Probe' Agent Class for the ns
 *       network simulator
 * Author: Antoine Bagula (bagula@cs.sun.ac.za), June 2000
 *
 */


#ifndef ns_probe_h
#define ns_probe_h

#include <stdio.h>
#include <iostream.h>
#include <iomanip.h> 
#include <stdlib.h>
#include "agent.h"
#include "tclcl.h"
#include "packet.h"
#include "address.h"
#include "ip.h"
#include "route.h"
#define INFINITY	0x3fff
#define INDEX(i, j, N) ((N) * (i) + (j))        


struct hdr_probe {
  char ret;
  double send_time;
  double return_time;
  double end_time;
};


class ProbeAgent : public Agent {
 public:
  ProbeAgent();
  int command(int argc, const char*const* argv);
  void recv(Packet*, Handler*);
 protected:
  int off_probe_;
};


#endif
