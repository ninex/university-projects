#ifndef	alt_H
#define	alt_H


class nodes {
   public:
      nodes(void);
   public:
      void    add_route(int L, int id, int * ptr);
   public:
        int  id; // Identity of a node
	node *  entry;   // pointer to a node entries
};

//---------------------------------------------------------------------------

class node {
   public:
      	node(void);
   public:
      	void    add_route(int dst); // add a route to another node
	int 	bpsc(); // backward propagation source control
	int 	bppc(); // backward propagation progressive control
	int 	fpdc(); // forward propagation destination control
	int 	fppc(); // forward propagation progressive control
	int     ntc1(); // next hop target control one control node
	int     ntc2(); // nest hop target control two control nodes
   public:
      	int	Id;	  // Identity of this Node
      	int	* ct;	  // entry to an array of path costs to other nodes
      	int	* lt;	  // entry to an array of path length to other nodes
      	int     * bt;     // entry to an array of path bandwidth to other nodes	
};
#endif
