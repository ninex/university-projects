/*
 * ObjectClient.java
 *
 * Demonstrates how to send an object over a socket
 *
 * Created on 23 July 2004, 10:55
 */
import java.io.*;
import java.net.*;
import java.util.*;
public class ObjectClient {
    
    private static int PORT = 3000;
    private static String hostname = "localhost";
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Socket s = new Socket(hostname, PORT);
            System.out.println("Connected to " + s.getInetAddress());
            ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
            LinkedList l = new LinkedList();
            l.add(new String("Hello"));
            l.add(new String("World."));
            l.add(new Integer(123));
            System.out.println("Sending Linked List");
            oos.writeObject(l);
            System.out.println("Done.");
            oos.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
        
        
    }
    
}
