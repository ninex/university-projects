/*
 * ObjectServer.java
 *
 * Demonstrates how to send an object over a socket
 *
 * Created on 23 July 2004, 10:55
 */
import java.io.*;
import java.net.*;
import java.util.*;
public class ObjectServer {
    
    private static int PORT = 3000;
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            ServerSocket servSock = new ServerSocket(PORT);
            Socket sock = servSock.accept();
            System.out.println("Connected to " + sock.getInetAddress());
            
            System.out.println("Going to get a linked list from the client now.");
            ObjectInputStream ois = new ObjectInputStream(sock.getInputStream());
            
            try {          
                LinkedList l = (LinkedList) ois.readObject();
                Iterator iter = l.iterator();
                System.out.println("The linked list contained: ");
                while (iter.hasNext()) 
                    System.out.println(iter.next().toString());
                System.out.println("Done now. Bye.");
                
            } catch (ClassCastException cce) {
                System.out.println("Client did not send a linked list.");
                System.out.println(cce.getMessage());
                System.exit(-1);
            } catch (ClassNotFoundException cnfe) {
                System.out.println("Client did not send a linked list.");
                System.out.println(cnfe.getMessage());
                System.exit(-1);
            }
            
            ois.close();
                        
        } catch (IOException iox) {
            System.out.println(iox.getMessage());
            System.exit(-1);
        }
    }
    
}
