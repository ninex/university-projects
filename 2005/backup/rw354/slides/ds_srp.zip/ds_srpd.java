/** DS 2004/07/22 Modified version of knockknockserver
  * Simply stripped the knockknock protocol and changed
  * the interaction between the client and server.
  * You can think of this as a chat program. The server
  * needs to be running first "java ds_srpd". In another
  * console you can now run the client "java ds_srp".
  * The server waits for the first contact from the client
  * Type a message. It will display at the server end.
  * Then the server can type a message back and so forth.
  * If you wish to end the chat session- the server has to
  * type "Bye." and the connection closes.
  * More comments made inline...
  */
  
import java.net.*;  // to use the socket API
import java.io.*;   // to use the input and output streams

public class ds_srpd {
    public static void main(String[] args) throws IOException {
    
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(5001);  // choose the port number for connection here
        } catch (IOException e) {
            System.err.println("Could not listen on port: 5001.");
            System.exit(1);
        }

	System.out.println("Server running on port 5001. Waiting for the client connection...");
        Socket clientSocket = null;
        try {
	    /** Note that ServerSocket.accept() is a blocking call. 
	      * We wait (block) until we accept a client connection.
	      * Once a client makes a connection we continue execution
	      */
            clientSocket = serverSocket.accept();
        } catch (IOException e) {
            System.err.println("Accept failed.");
            System.exit(1);
        }

	BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));  // input stream from your keyboard
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);      // connect to client output stream (what server says to client)
        BufferedReader in = new BufferedReader(
				new InputStreamReader(
				clientSocket.getInputStream()));                      // connect to client input stream (what client says to server)
        String inputLine, outputLine;
        outputLine = "Hello. Got you loud and clear client...";
        out.println(outputLine);

        while ((inputLine = in.readLine()) != null) {                    // read message from the client
             System.out.println("The client says: " + inputLine);        // display it on server console
	     System.out.print("Type your message and press [Enter]: ");
	     outputLine = stdIn.readLine();                              // read server message from keyboard
             out.println(outputLine);                                    // send message to the client
             if (outputLine.equals("Bye."))                              // this sets the message that closes the connection
                break;
        }
        out.close();                                                     // remember to close your streams and sockets!
        in.close();
        clientSocket.close();
        serverSocket.close();
    }
}