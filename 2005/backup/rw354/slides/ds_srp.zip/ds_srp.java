/** DS 2004/07/22 See ds_srpd.java for explanation of the
  * client (ds_srp) and server (ds_srpd).
  * More comments made inline...
  */
import java.io.*;   // to use the socket API
import java.net.*;  // to use the input and output streams

public class ds_srp {
    public static void main(String[] args) throws IOException {

        Socket DaemonSocket = null;  // the socket connection we will make to the server
        PrintWriter out = null;      // the data we write to the server
        BufferedReader in = null;    // the data we receive from the server

        try {
            DaemonSocket = new Socket("localhost", 5001);                                   // must match port set in ds_srpd, where ServerSocket called
            out = new PrintWriter(DaemonSocket.getOutputStream(), true);                    // get handle to the server's output stream
            in = new BufferedReader(new InputStreamReader(DaemonSocket.getInputStream()));  // get handle to the server's input stream
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host: localhost.");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to: localhost.");
            System.exit(1);
        }

        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));        // input stream from your keyboard
        String fromServer;
        String fromUser;

        while ((fromServer = in.readLine()) != null) {                                      // read the message from the server
            System.out.println("Server says: " + fromServer);                               // display it on the client console
            if (fromServer.equals("Bye."))                                                  // the server wants to disconnect - so client disconnect too
                break;
		    
            System.out.print("Type your message and press [Enter]: ");
	    fromUser = stdIn.readLine();                                                    // read client message from the keyboard
	    if (fromUser != null) {
                out.println(fromUser);                                                      // send message to the server
	    }
        }

        out.close();                                                                        // remember to close your streams and sockets!
        in.close();
        stdIn.close();
        DaemonSocket.close();
    }
}