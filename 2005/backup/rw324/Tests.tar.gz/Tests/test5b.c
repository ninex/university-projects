int main()
{
 	long int mcounter,msubcounter;
	clock_t tick1,tick2;
	float answer;
 	
	/*Initialization phaze*/
	mcounter = 1;
	msubcounter = 1;
	
	/*processing phaze*/
	tick1 = clock();

	// Iterating n times
	while(mcounter <= 30000000)
	{
		while( msubcounter <= 500000 )
		{
			msubcounter = msubcounter + 1;
			mcounter = mounter + 1;

		}
		printf("another 500000 cycles has passed\n");
		msubcounter = 1;
		mcounter = mcounter + 1;
	}

	tick2 = clock();
	tick1 = tick2 - tick1;
	answer = ( ( float )tick1/( float )CLOCKS_PER_SEC) * 1000;
	printf( "It took %f miliseconds to finish the while\n",answer );

	return EXIT_SUCCESS;
 }
 
