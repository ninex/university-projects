int main()
{
	int input, testNum, numberOfSevens, inputsave;
	numberOfSevens = 0;
	printf("Please enter a number: \t");
	scanf("%i", &input);
	inputsave = input;	/* save the input */
	do
	{
		testNum = input%10;	/* testNum = input MOD 10 */	
		input = input/10;	/* Integer division ! */
		if (testNum == 7)
		{
			numberOfSevens++;
		}
	}while(input > 0);		
	printf("The amount of sevens in %i is %i \n", inputsave, numberOfSevens);
	return EXIT_SUCCESS;
}

