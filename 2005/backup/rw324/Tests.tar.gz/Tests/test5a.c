/******************************************************************************
 * This program tests the speed of the computer by taking a time stamp at     *
 * known intervals in a simple while loop				      *
 ******************************************************************************/
 
int main(){
 	long int ncounter,nsubcounter;
	clock_t tick1,tick2;
	float answer;
 	
	/*Initialization phaze*/
	ncounter = 1;
	nsubcounter = 1;
	
	/*processing phaze*/
	tick1 = clock();
	while(ncounter <= 30000000){
		while(nsubcounter <= 500000){
			++nsubcounter;
			++ncounter;
			
		}
		printf("another 500000 cycles has passed\n");
		nsubcounter = 1;
		++ncounter;
	}
	tick2 = clock();
	tick1 = tick2-tick1;
	answer = ((float)tick1/(float)CLOCKS_PER_SEC)*1000;
	printf("It took %f miliseconds to finish the while\n",answer);
 	return EXIT_SUCCESS;
 }
 
