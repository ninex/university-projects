/**
 * Calculates the mean of an array
 */
int meanCalc( int *val, int len )
{
	int i = 0;
	int mean = 0;
	while( i < len )
	{
		mean = mean + val[i];
		i = i + 1;
	}
	mean = mean / len;
}

int main()
{
	int [] val = {1, 2, 3, 4};
	int mean = meanCalc( val, 4 );
	printf( "The mean is %i\n", mean );
	return EXIT_SUCCESS;
}
