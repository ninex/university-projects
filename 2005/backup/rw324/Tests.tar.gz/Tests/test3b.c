/**
 * Calculates the mean of a series of numbers
 * The numbers is in an array
 */
int meanCalc( int *val, int len )
{
	int i;
	int mean = 0;
	for( i = 0; i < len; i++ )
	{
		mean = mean + val[i];
	}
	mean = mean / len;
}

int main()
{
	int [] val = {1, 2, 3, 4};
	int mean = meanCalc( val, 4 );
	printf( "The mean is %i\n", mean );
	return EXIT_SUCCESS;
}
