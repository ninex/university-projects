int main()
{
	printf( "Hello Computer Science 324\n" );
	return EXIT_SUCCESS;
}
