/******************************************************************************
 * This program calculates the amount of 7's in a certain number	      *
 ******************************************************************************/

int calcSevens( int input )
{
	int numberOfSevens = 0;
	int testNum;
	do
	{
		testNum = input%10;	/* testNum = input MOD 10 */	
		input = input/10;	/* Integer division ! */
		if (testNum == 7)
		{
			numberOfSevens++;
		}
	}while(input > 0);
	return numberOfSevens;
}

int main()
{
	int input, testNum, numberOfSevens;
	numberOfSevens = 0;
	printf("Please enter a number: \t");
	scanf("%i", &input);
	numberOfSevens = calcSevens( input );
	printf("The amount of sevens in %i is %i \n", input, numberOfSevens);
	return EXIT_SUCCESS;
}

