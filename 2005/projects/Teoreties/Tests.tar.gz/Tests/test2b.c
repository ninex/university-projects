int main()
{
	printf( "Hello  Computer  Science  324\n" );
  return 0;
}
