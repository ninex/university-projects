/**
 * Calculates the mean of an array
 */
int meanCalc( int *val, int length )
{
	int i = 0;
	int mean = 0;
	while( i < length )
	{
		mean = mean + val[i];
		i = i + 1;
	}
	mean = mean / length;
}

int main()
{
	int val[] = {1, 2, 3, 4};
	int mean = meanCalc( val, 4 );
	printf( "The mean is %d\n", mean );
	return 0;
}
