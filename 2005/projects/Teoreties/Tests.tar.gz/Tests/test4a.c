int main()
{
	int input, testNum, numberOfSevens, inputsave;
	numberOfSevens = 0;
	printf("Please enter a number: \t");
	scanf("%d", &input);
	inputsave = input;	/* save the input */
	do
	{
		testNum = input%10;	/* testNum = input MOD 10 */	
		input = input/10;	/* Integer division ! */
		if (testNum == 7)
		{
			numberOfSevens++;
		}
	}while(input > 0);		
	printf("The number of sevens in %d are %d \n", inputsave, numberOfSevens);
	return 0;
}

