public class projek
{

//=========================================================================================  
  public static void main(String[] args)
  {
    window.setup();
  }
}
